import '../models/course_model.dart';
import 'api_service.dart';

class CourseService {
  // Get All Courses
  static Future<List<Course>> getAllCourses({
    String? category,
    String? search,
    String sortBy = 'created_at',
    String sortOrder = 'desc',
  }) async {
    try {
      String endpoint = '/courses?sort_by=$sortBy&sort_order=$sortOrder';
      
      if (category != null && category.isNotEmpty) {
        endpoint += '&category=$category';
      }
      
      if (search != null && search.isNotEmpty) {
        endpoint += '&search=$search';
      }

      final response = await ApiService.get(endpoint);

      if (response['success'] == true) {
        final List<dynamic> coursesJson = response['data']['data'];
        return coursesJson.map((json) => Course.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print('Get courses error: $e');
      return [];
    }
  }

  // Get Course Detail
  static Future<Course?> getCourseDetail(int id) async {
    try {
      final response = await ApiService.get('/courses/$id');

      if (response['success'] == true) {
        return Course.fromJson(response['data']);
      }

      return null;
    } catch (e) {
      print('Get course detail error: $e');
      return null;
    }
  }

  // Get Popular Courses
  static Future<List<Course>> getPopularCourses() async {
    try {
      final response = await ApiService.get('/courses/popular');

      if (response['success'] == true) {
        final List<dynamic> coursesJson = response['data'];
        return coursesJson.map((json) => Course.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print('Get popular courses error: $e');
      return [];
    }
  }

  // Get Courses by Category
  static Future<List<Course>> getCoursesByCategory(String category) async {
    try {
      final response = await ApiService.get('/courses/category/$category');

      if (response['success'] == true) {
        final List<dynamic> coursesJson = response['data']['data'];
        return coursesJson.map((json) => Course.fromJson(json)).toList();
      }

      return [];
    } catch (e) {
      print('Get courses by category error: $e');
      return [];
    }
  }

  // Create Course (butuh auth & role instructor)
  static Future<Map<String, dynamic>> createCourse({
    required String category,
    required String title,
    required String description,
    required int contentCount,
    required String duration,
    required double price,
    required String imageUrl,
    String status = 'published',
  }) async {
    try {
      final response = await ApiService.post(
        '/courses',
        {
          'category': category,
          'title': title,
          'description': description,
          'content_count': contentCount,
          'duration': duration,
          'price': price,
          'image_url': imageUrl,
          'status': status,
        },
        requiresAuth: true,
      );

      if (response['success'] == true) {
        return {
          'success': true,
          'course': Course.fromJson(response['data']),
          'message': response['message'],
        };
      }

      return {
        'success': false,
        'message': response['message'] ?? 'Create course failed',
      };
    } catch (e) {
      return {
        'success': false,
        'message': e.toString().replaceAll('Exception: ', ''),
      };
    }
  }

  // Update Course
  static Future<Map<String, dynamic>> updateCourse({
    required int id,
    String? category,
    String? title,
    String? description,
    int? contentCount,
    String? duration,
    double? price,
    String? imageUrl,
    String? status,
  }) async {
    try {
      Map<String, dynamic> body = {};
      if (category != null) body['category'] = category;
      if (title != null) body['title'] = title;
      if (description != null) body['description'] = description;
      if (contentCount != null) body['content_count'] = contentCount;
      if (duration != null) body['duration'] = duration;
      if (price != null) body['price'] = price;
      if (imageUrl != null) body['image_url'] = imageUrl;
      if (status != null) body['status'] = status;

      final response = await ApiService.put(
        '/courses/$id',
        body,
        requiresAuth: true,
      );

      if (response['success'] == true) {
        return {
          'success': true,
          'course': Course.fromJson(response['data']),
          'message': response['message'],
        };
      }

      return {
        'success': false,
        'message': response['message'] ?? 'Update course failed',
      };
    } catch (e) {
      return {
        'success': false,
        'message': e.toString().replaceAll('Exception: ', ''),
      };
    }
  }

  // Delete Course
  static Future<Map<String, dynamic>> deleteCourse(int id) async {
    try {
      final response = await ApiService.delete('/courses/$id', requiresAuth: true);

      if (response['success'] == true) {
        return {
          'success': true,
          'message': response['message'],
        };
      }

      return {
        'success': false,
        'message': response['message'] ?? 'Delete course failed',
      };
    } catch (e) {
      return {
        'success': false,
        'message': e.toString().replaceAll('Exception: ', ''),
      };
    }
  }

  // Enroll Course
  static Future<Map<String, dynamic>> enrollCourse(int id) async {
    try {
      final response = await ApiService.post(
        '/courses/$id/enroll',
        {},
        requiresAuth: true,
      );

      if (response['success'] == true) {
        return {
          'success': true,
          'message': response['message'],
        };
      }

      return {
        'success': false,
        'message': response['message'] ?? 'Enroll failed',
      };
    } catch (e) {
      return {
        'success': false,
        'message': e.toString().replaceAll('Exception: ', ''),
      };
    }
  }
}