import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // ✅ PERBAIKAN: Pastikan URL ini benar
  static const String baseUrl = 'http://127.0.0.1:8000/api';

  static Future<Map<String, String>> getHeaders({bool requiresAuth = false}) async {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (requiresAuth) {
      final token = await getToken();
      if (token != null) {
        headers['Authorization'] = 'Bearer $token';
      }
    }

    return headers;
  }

  // Simpan token
  static Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    print('✅ Token saved: ${token.substring(0, 20)}...'); // Debug
  }

  // Get token
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token');
    print('🔑 Token retrieved: ${token != null ? token.substring(0, 20) + "..." : "null"}'); // Debug
    return token;
  }

  // Simpan user data
  static Future<void> saveUser(Map<String, dynamic> user) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_data', jsonEncode(user));
    print('✅ User data saved: ${user['name']}'); // Debug
  }

  // Get user data
  static Future<Map<String, dynamic>?> getUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userData = prefs.getString('user_data');
    if (userData != null) {
      return jsonDecode(userData);
    }
    return null;
  }

  // Hapus token dan user data (logout)
  static Future<void> clearAuth() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');
    await prefs.remove('user_data');
    print('🚪 Auth cleared'); // Debug
  }

  // Check if logged in
  static Future<bool> isLoggedIn() async {
    final token = await getToken();
    return token != null && token.isNotEmpty;
  }

  // GET Request
  static Future<dynamic> get(String endpoint, {bool requiresAuth = false}) async {
    try {
      final headers = await getHeaders(requiresAuth: requiresAuth);
      final url = Uri.parse('$baseUrl$endpoint');
      
      print('🌐 GET Request: $url'); // Debug
      print('📋 Headers: $headers'); // Debug
      
      final response = await http.get(url, headers: headers)
          .timeout(const Duration(seconds: 10));

      print('📥 Response Status: ${response.statusCode}'); // Debug
      print('📥 Response Body: ${response.body}'); // Debug

      return _handleResponse(response);
    } catch (e) {
      print('❌ GET Error: $e'); // Debug
      throw Exception('Network error: ${_getErrorMessage(e)}');
    }
  }

  // POST Request
  static Future<dynamic> post(String endpoint, dynamic body, {bool requiresAuth = false}) async {
    try {
      final headers = await getHeaders(requiresAuth: requiresAuth);
      final url = Uri.parse('$baseUrl$endpoint');
      
      print('🌐 POST Request: $url'); // Debug
      print('📋 Headers: $headers'); // Debug
      print('📤 Body: ${jsonEncode(body)}'); // Debug
      
      final response = await http.post(
        url,
        headers: headers,
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 10));

      print('📥 Response Status: ${response.statusCode}'); // Debug
      print('📥 Response Body: ${response.body}'); // Debug

      return _handleResponse(response);
    } catch (e) {
      print('❌ POST Error: $e'); // Debug
      throw Exception('Network error: ${_getErrorMessage(e)}');
    }
  }

  // PUT Request
  static Future<dynamic> put(String endpoint, dynamic body, {bool requiresAuth = false}) async {
    try {
      final headers = await getHeaders(requiresAuth: requiresAuth);
      final url = Uri.parse('$baseUrl$endpoint');
      
      print('🌐 PUT Request: $url'); // Debug
      
      final response = await http.put(
        url,
        headers: headers,
        body: jsonEncode(body),
      ).timeout(const Duration(seconds: 10));

      return _handleResponse(response);
    } catch (e) {
      print('❌ PUT Error: $e'); // Debug
      throw Exception('Network error: ${_getErrorMessage(e)}');
    }
  }

  // DELETE Request
  static Future<dynamic> delete(String endpoint, {bool requiresAuth = false}) async {
    try {
      final headers = await getHeaders(requiresAuth: requiresAuth);
      final url = Uri.parse('$baseUrl$endpoint');
      
      print('🌐 DELETE Request: $url'); // Debug
      
      final response = await http.delete(url, headers: headers)
          .timeout(const Duration(seconds: 10));

      return _handleResponse(response);
    } catch (e) {
      print('❌ DELETE Error: $e'); // Debug
      throw Exception('Network error: ${_getErrorMessage(e)}');
    }
  }

  // Handle Response
  static dynamic _handleResponse(http.Response response) {
    try {
      final body = jsonDecode(response.body);

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return body;
      } else if (response.statusCode == 401) {
        clearAuth();
        throw Exception('Session expired. Please login again.');
      } else {
        String errorMessage = 'An error occurred';
        
        if (body['message'] != null) {
          errorMessage = body['message'];
        } else if (body['errors'] != null) {
          final errors = body['errors'] as Map<String, dynamic>;
          errorMessage = errors.values.first[0];
        }
        
        throw Exception(errorMessage);
      }
    } catch (e) {
      if (e is Exception) rethrow;
      throw Exception('Failed to parse response');
    }
  }

  // Get error message
  static String _getErrorMessage(dynamic error) {
    if (error.toString().contains('SocketException')) {
      return 'No internet connection. Make sure Laravel server is running!';
    } else if (error.toString().contains('TimeoutException')) {
      return 'Connection timeout';
    }
    return error.toString();
  }
}