// lib/services/auth_service.dart
import '../models/user_model.dart';
import 'api_service.dart';

class AuthService {
  // Register
  static Future<Map<String, dynamic>> register({
    required String name,
    required String email,
    required String password,
    String? phone,
  }) async {
    try {
      final response = await ApiService.post('/auth/register', {
        'name': name,
        'email': email,
        'password': password,
        'phone': phone,
      });

      if (response['success'] == true) {
        // Simpan token dan user data
        await ApiService.saveToken(response['data']['token']);
        await ApiService.saveUser(response['data']['user']);
        
        return {
          'success': true,
          'user': User.fromJson(response['data']['user']),
          'message': response['message'] ?? 'Registration successful',
        };
      }

      return {
        'success': false,
        'message': response['message'] ?? 'Registration failed',
      };
    } catch (e) {
      return {
        'success': false,
        'message': e.toString().replaceAll('Exception: ', ''),
      };
    }
  }

  // Login
  static Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    try {
      final response = await ApiService.post('/auth/login', {
        'email': email,
        'password': password,
      });

      if (response['success'] == true) {
        // Simpan token dan user data
        await ApiService.saveToken(response['data']['token']);
        await ApiService.saveUser(response['data']['user']);
        
        return {
          'success': true,
          'user': User.fromJson(response['data']['user']),
          'message': response['message'] ?? 'Login successful',
        };
      }

      return {
        'success': false,
        'message': response['message'] ?? 'Login failed',
      };
    } catch (e) {
      return {
        'success': false,
        'message': e.toString().replaceAll('Exception: ', ''),
      };
    }
  }

  // Get Profile (dari API)
  static Future<User?> getProfile() async {
    try {
      final response = await ApiService.get('/auth/profile', requiresAuth: true);

      if (response['success'] == true) {
        final user = User.fromJson(response['data']);
        // Update user data di local storage
        await ApiService.saveUser(response['data']);
        return user;
      }

      return null;
    } catch (e) {
      print('Get profile error: $e');
      return null;
    }
  }

  // Get Profile dari local storage (lebih cepat)
  static Future<User?> getLocalProfile() async {
    try {
      final userData = await ApiService.getUser();
      if (userData != null) {
        return User.fromJson(userData);
      }
      return null;
    } catch (e) {
      print('Get local profile error: $e');
      return null;
    }
  }

  // Update Profile (UPDATED - dengan avatar)
  static Future<Map<String, dynamic>> updateProfile({
    String? name,
    String? phone,
    String? bio,
    String? avatar, // ✅ TAMBAHAN
  }) async {
    try {
      Map<String, dynamic> body = {};
      if (name != null) body['name'] = name;
      if (phone != null) body['phone'] = phone;
      if (bio != null) body['bio'] = bio;
      if (avatar != null) body['avatar'] = avatar; // ✅ TAMBAHAN

      final response = await ApiService.put('/auth/profile', body, requiresAuth: true);

      if (response['success'] == true) {
        // Update user data di local storage
        await ApiService.saveUser(response['data']);
        
        return {
          'success': true,
          'user': User.fromJson(response['data']),
          'message': response['message'] ?? 'Profile updated successfully',
        };
      }

      return {
        'success': false,
        'message': response['message'] ?? 'Update failed',
      };
    } catch (e) {
      return {
        'success': false,
        'message': e.toString().replaceAll('Exception: ', ''),
      };
    }
  }

  // Logout
  static Future<bool> logout() async {
    try {
      // Panggil API logout
      await ApiService.post('/auth/logout', {}, requiresAuth: true);
      // Hapus token dan user data
      await ApiService.clearAuth();
      return true;
    } catch (e) {
      // Tetap hapus token meskipun request gagal
      await ApiService.clearAuth();
      return true;
    }
  }

  // Check if logged in
  static Future<bool> isLoggedIn() async {
    return await ApiService.isLoggedIn();
  }

  // Refresh token
  static Future<Map<String, dynamic>> refreshToken() async {
    try {
      final response = await ApiService.post('/auth/refresh', {}, requiresAuth: true);

      if (response['success'] == true) {
        await ApiService.saveToken(response['data']['token']);
        return {
          'success': true,
          'message': 'Token refreshed',
        };
      }

      return {
        'success': false,
        'message': 'Failed to refresh token',
      };
    } catch (e) {
      return {
        'success': false,
        'message': e.toString().replaceAll('Exception: ', ''),
      };
    }
  }
}