import 'package:flutter/material.dart';

class GraduationCapPainter extends CustomPainter {
  final Color color;
  final Color accentColor;

  GraduationCapPainter({
    required this.color,
    required this.accentColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 8.0
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final accentPaint = Paint()
      ..color = accentColor
      ..style = PaintingStyle.fill;

    final w = size.width;
    final h = size.height;

    // Draw cube outline
    final Path cubePath = Path();
    
    // Front face
    cubePath.moveTo(w * 0.3, h * 0.55);
    cubePath.lineTo(w * 0.3, h * 0.85);
    cubePath.lineTo(w * 0.7, h * 0.85);
    cubePath.lineTo(w * 0.7, h * 0.55);
    
    // Right face
    cubePath.moveTo(w * 0.7, h * 0.55);
    cubePath.lineTo(w * 0.85, h * 0.45);
    cubePath.lineTo(w * 0.85, h * 0.75);
    cubePath.lineTo(w * 0.7, h * 0.85);
    
    // Top face (cap base)
    cubePath.moveTo(w * 0.3, h * 0.55);
    cubePath.lineTo(w * 0.45, h * 0.45);
    cubePath.lineTo(w * 0.85, h * 0.45);
    cubePath.lineTo(w * 0.7, h * 0.55);
    cubePath.close();

    canvas.drawPath(cubePath, paint);

    // Draw graduation cap top (diamond shape)
    final Path capPath = Path();
    capPath.moveTo(w * 0.5, h * 0.15); // Top point
    capPath.lineTo(w * 0.25, h * 0.35); // Left point
    capPath.lineTo(w * 0.5, h * 0.45); // Bottom point
    capPath.lineTo(w * 0.75, h * 0.35); // Right point
    capPath.close();

    canvas.drawPath(capPath, paint);

    // Draw tassel
    final Path tasselPath = Path();
    tasselPath.moveTo(w * 0.75, h * 0.35);
    tasselPath.lineTo(w * 0.85, h * 0.35);
    tasselPath.lineTo(w * 0.85, h * 0.25);

    canvas.drawPath(tasselPath, paint);

    // Draw accent ribbon/book inside
    final Rect ribbonRect = Rect.fromLTWH(
      w * 0.4,
      h * 0.62,
      w * 0.2,
      h * 0.15,
    );
    canvas.drawRect(ribbonRect, accentPaint);

    // Draw lines on book
    final linePaint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.0;

    canvas.drawLine(
      Offset(w * 0.42, h * 0.68),
      Offset(w * 0.52, h * 0.68),
      linePaint,
    );
    canvas.drawLine(
      Offset(w * 0.42, h * 0.72),
      Offset(w * 0.52, h * 0.72),
      linePaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}