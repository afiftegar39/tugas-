// constants/colors.dart
import 'package:flutter/material.dart';

class AppColors {
  static const primaryBlue = Color(0xFF0052D4);
  static const darkBlue = Color(0xFF001B48);
  static const lightBlue = Color(0xFF4364F7);
  static const orange = Color(0xFFFF8C00);
  static const white = Color(0xFFFFFFFF);
  static const grey = Color(0xFF757575);
  static const lightGrey = Color(0xFFE0E0E0);
  
  
  static const gradientBlue = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0xFF0052D4),
      Color(0xFF1E3A8A),
    ],
  );
  
  static const overlayGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [
      Color(0x990052D4),
      Color(0xCC1E3A8A),
    ],
  );
}