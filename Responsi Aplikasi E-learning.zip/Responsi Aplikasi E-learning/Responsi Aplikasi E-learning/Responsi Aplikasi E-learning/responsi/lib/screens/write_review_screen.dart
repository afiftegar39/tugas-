// screens/write_review_screen.dart
import 'package:flutter/material.dart';
import '../constants/colors.dart';

class WriteReviewScreen extends StatefulWidget {
  const WriteReviewScreen({Key? key}) : super(key: key);

  @override
  State<WriteReviewScreen> createState() => _WriteReviewScreenState();
}

class _WriteReviewScreenState extends State<WriteReviewScreen> {
  final TextEditingController _reviewController = TextEditingController();

  @override
  void dispose() {
    _reviewController.dispose();
    super.dispose();
  }

  // Fungsi untuk mengirim review kembali ke layar sebelumnya
  void _submitReview() {
    // Hanya pop jika ada teks yang ditulis
    if (_reviewController.text.trim().isNotEmpty) {
      Navigator.pop(context, _reviewController.text.trim());
    } else {
      // Jika kosong, kembali saja tanpa mengirim data
      Navigator.pop(context);
    }
  }

  // --- WIDGET BARU UNTUK MENAMPILKAN REVIEW 'KEVIN SIRAIT' ---
  // (Dibuat hardcoded agar sesuai dengan gambar Anda)
  Widget _buildKevinSiraitReview() {
    const String imageUrl = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80';
    const String name = 'Kevin Sirait';
    const String text = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod';
    const int likes = 45;
    const int replies = 4;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CircleAvatar(
          radius: 24,
          backgroundImage: NetworkImage(imageUrl),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                name,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                text,
                style: TextStyle(
                  color: Colors.grey[700],
                  fontSize: 14,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  const Icon(Icons.thumb_up_alt_outlined,
                      size: 16, color: Colors.green),
                  const SizedBox(width: 4),
                  Text(
                    '$likes Like',
                    style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 13,
                        fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(width: 20),
                  const Icon(Icons.reply_outlined,
                      size: 16, color: Colors.blue),
                  const SizedBox(width: 4),
                  Text(
                    '$replies Reply',
                    style: TextStyle(
                        color: Colors.grey[600],
                        fontSize: 13,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Write Reviews', // Judul dari gambar Anda
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      // --- MODIFIKASI BAGIAN BODY ---
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              // 1. Tambahkan review Kevin Sirait di sini
              _buildKevinSiraitReview(),

              const SizedBox(height: 24), // Beri jarak

              // 2. Modifikasi TextField
              TextField(
                controller: _reviewController,
                autofocus: true,
                maxLines: 8, // Tentukan jumlah baris, hapus 'expands: true'
                keyboardType: TextInputType.multiline,
                decoration: InputDecoration(
                  hintText: 'Write your review here...',
                  // 3. Tambahkan border seperti di gambar
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                    borderSide: BorderSide(
                      color: Colors.grey[400]!,
                      width: 1.0,
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                    borderSide: BorderSide(
                      color: Colors.grey[400]!,
                      width: 1.0,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                    borderSide: const BorderSide(
                      color: AppColors.primaryBlue,
                      width: 1.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      // Tombol submit tetap di bawah
      bottomNavigationBar: Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16,
            MediaQuery.of(context).viewInsets.bottom + 16), // Menyesuaikan dengan keyboard
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primaryBlue,
            minimumSize: const Size(double.infinity, 50),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          onPressed: _submitReview,
          child: const Text(
            'SUBMIT REVIEW',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
      ),
    );
  }
}