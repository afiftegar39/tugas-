// lib/screens/about_framework_screen.dart
import 'package:flutter/material.dart';
import '../constants/colors.dart';

class AboutFrameworkScreen extends StatelessWidget {
  const AboutFrameworkScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'About',
          style: TextStyle(color: Colors.black87, fontSize: 18),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'About',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Welcome to Framework7',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.primaryBlue, // Menggunakan warna primer Anda
              ),
            ),
            const SizedBox(height: 16),
            _buildParagraph(
                'Framework7 - is a free and open source HTML mobile framework to develop hybrid mobile apps or web apps with iOS or Android (Material) native look and feel. It is also an indispensable prototyping apps tool to show working app prototype as soon as possible in case you need to. Framework7 is created by Vladimir Kharlampidi.'),
            const SizedBox(height: 16),
            _buildParagraph(
                'The main approach of the Framework7 is to give you an opportunity to create iOS and Android (Material) apps with HTML, CSS and JavaScript easily and clear. Framework7 is full of freedom. It doesn\'t limit your imagination or offer ways of any solutions somehow. Framework7 gives you freedom!'),
            const SizedBox(height: 16),
            _buildParagraph(
                'Framework7 is not compatible with all platforms. It is focused only on iOS and Android (Material) to bring the best experience and simplicity.'),
            const SizedBox(height: 16),
            _buildParagraph(
                'Framework7 is definitely for you if you decide to build iOS and Android hybrid app (Cordova or Capacitor) or web app that looks like and feels as great native iOS or Android (Material) apps.'),
          ],
        ),
      ),
    );
  }

  // Widget helper untuk membuat paragraf
  Widget _buildParagraph(String text) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 15,
        color: Colors.black54,
        height: 1.5, // Jarak antar baris
      ),
    );
  }
}