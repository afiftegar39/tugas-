// screens/phone_verification_screen.dart
import 'package:flutter/material.dart';
import '../constants/colors.dart';
import '../widgets/custom_button.dart';
import '../widgets/graduation_cap_painter.dart';
import 'home_screen.dart';
import 'login_screen.dart';
import 'sukses_send.dart';

class PhoneVerificationScreen extends StatefulWidget {
  const PhoneVerificationScreen({Key? key}) : super(key: key);

  @override
  State<PhoneVerificationScreen> createState() => _PhoneVerificationScreenState();
}

class _PhoneVerificationScreenState extends State<PhoneVerificationScreen> {
  String _selectedCountryCode = '+62';
  final TextEditingController _phoneController = TextEditingController();

  final List<TextEditingController> _otpControllers =
      List.generate(6, (index) => TextEditingController());
  final List<FocusNode> _otpFocusNodes = List.generate(6, (index) => FocusNode());

  bool _isCodeSent = false;

  @override
  void dispose() {
    _phoneController.dispose();
    for (var controller in _otpControllers) {
      controller.dispose();
    }
    for (var node in _otpFocusNodes) {
      node.dispose();
    }
    super.dispose();
  }

  void _sendCode() {
    // Langsung navigasi ke halaman sukses tanpa validasi
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => const SuksesSendScreen(),
      ),
    );
  }

  void _verifyCode() {
    String otp = _otpControllers.map((c) => c.text).join();
    if (otp.length == 6) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => const HomeScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter the complete 6-digit code.'),
          backgroundColor: AppColors.orange,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              // Logo dan Judul - Centered
              Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 48,
                      height: 48,
                      child: CustomPaint(
                        painter: GraduationCapPainter(
                          color: AppColors.primaryBlue,
                          accentColor: AppColors.orange,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Text(
                      'Ajari',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: AppColors.primaryBlue,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 48),
              Text(
                _isCodeSent ? 'Verify Phone' : 'Create an Account',
                style: const TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                _isCodeSent
                    ? 'We have sent a 6-digit code to ${_selectedCountryCode}${_phoneController.text}.'
                    : 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod',
                style: const TextStyle(
                  fontSize: 14,
                  color: AppColors.grey,
                  height: 1.5,
                ),
              ),
              const SizedBox(height: 40),

              if (!_isCodeSent) _buildPhoneNumberInput(),

              if (_isCodeSent) ...[
                _buildOtpInput(),
                const SizedBox(height: 30),
                Center(
                  child: GestureDetector(
                    onTap: () {
                      for (var c in _otpControllers) {
                        c.clear();
                      }
                      _otpFocusNodes[0].requestFocus();
                      // Simulasi pengiriman ulang kode
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('Verification code resent!'),
                          backgroundColor: Colors.green,
                        ),
                      );
                    },
                    child: RichText(
                      text: const TextSpan(
                        text: "Didn't receive the code? ",
                        style: TextStyle(
                          color: AppColors.grey,
                          fontSize: 14,
                        ),
                        children: [
                          TextSpan(
                            text: 'Resend Code',
                            style: TextStyle(
                              color: AppColors.primaryBlue,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],

              const SizedBox(height: 40),

              CustomButton(
                text: _isCodeSent ? 'VERIFY' : 'SEND',
                onPressed: _isCodeSent ? _verifyCode : _sendCode,
                backgroundColor: AppColors.primaryBlue,
              ),

              const SizedBox(height: 24),

              if (!_isCodeSent) ...[
                Center(
                  child: RichText(
                    textAlign: TextAlign.center,
                    text: TextSpan(
                      text: 'By tapping Sign up you accept all our ',
                      style: const TextStyle(
                        color: AppColors.grey,
                        fontSize: 13,
                        height: 1.5,
                      ),
                      children: [
                        WidgetSpan(
                          child: GestureDetector(
                            onTap: () {
                              // Handle terms tap
                            },
                            child: const Text(
                              'terms',
                              style: TextStyle(
                                color: AppColors.primaryBlue,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                        const TextSpan(text: ' and\n'),
                        WidgetSpan(
                          child: GestureDetector(
                            onTap: () {
                              // Handle condition tap
                            },
                            child: const Text(
                              'condition',
                              style: TextStyle(
                                color: AppColors.primaryBlue,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 60),
                const Center(
                  child: Text(
                    'Already have an account?',
                    style: TextStyle(
                      color: AppColors.grey,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                CustomButton(
                  text: 'SIGN IN',
                  onPressed: () {
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(
                        builder: (context) => const LoginScreen(),
                      ),
                    );
                  },
                  isOutlined: true,
                  textColor: AppColors.primaryBlue,
                ),
              ],
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPhoneNumberInput() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        border: Border.all(
          color: AppColors.orange,
          width: 1.5,
        ),
        color: Colors.white,
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: const BoxDecoration(
              border: Border(
                right: BorderSide(color: Color(0xFFE0E0E0), width: 1.0),
              ),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedCountryCode,
                icon: const Icon(Icons.keyboard_arrow_down, color: Colors.black87),
                style: const TextStyle(color: Colors.black87, fontSize: 16),
                items: ['+62', '+1', '+44', '+81'].map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedCountryCode = value!;
                  });
                },
              ),
            ),
          ),
          Expanded(
            child: TextField(
              controller: _phoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                hintText: 'Type your phone num',
                hintStyle: TextStyle(
                  color: AppColors.grey,
                  fontSize: 15,
                ),
                filled: true,
                fillColor: Colors.white,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 15,
                  vertical: 18,
                ),
                border: InputBorder.none,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOtpInput() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(6, (index) {
        return SizedBox(
          width: 40,
          child: TextFormField(
            controller: _otpControllers[index],
            focusNode: _otpFocusNodes[index],
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            maxLength: 1,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppColors.primaryBlue,
            ),
            decoration: const InputDecoration(
              counterText: "",
              contentPadding: EdgeInsets.symmetric(vertical: 8),
              enabledBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: Color(0xFFE0E0E0), width: 1.5),
              ),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: AppColors.primaryBlue, width: 2),
              ),
            ),
            onChanged: (value) {
              if (value.isNotEmpty) {
                if (index < 5) {
                  _otpFocusNodes[index + 1].requestFocus();
                } else {
                  _otpFocusNodes[index].unfocus();
                  _verifyCode();
                }
              } else if (index > 0) {
                _otpFocusNodes[index - 1].requestFocus();
              }
            },
          ),
        );
      }),
    );
  }
}