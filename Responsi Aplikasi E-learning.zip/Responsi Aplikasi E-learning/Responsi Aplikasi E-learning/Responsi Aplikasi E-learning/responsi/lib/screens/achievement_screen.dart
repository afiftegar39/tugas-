// screens/achievement_screen.dart
import 'package:flutter/material.dart';
import '../constants/colors.dart';

class AchievementScreen extends StatefulWidget { // Ubah menjadi StatefulWidget
  const AchievementScreen({Key? key}) : super(key: key);

  @override
  State<AchievementScreen> createState() => _AchievementScreenState();
}

class _AchievementScreenState extends State<AchievementScreen> { // Tambahkan State
  String _selectedSortOption = 'Latest'; // State baru untuk menyimpan pilihan

  // Data ini diduplikasi dari layar detail agar layar ini mandiri
  late List<Map<String, dynamic>> achievements; // Ubah menjadi late List

  @override
  void initState() {
    super.initState();
    achievements = _generateInitialAchievements(); // Inisialisasi data
    _sortAchievements(); // Urutkan saat inisialisasi
  }

  // Fungsi untuk membuat data achievement awal
  List<Map<String, dynamic>> _generateInitialAchievements() {
    return [
      {
        'title': 'Completed UI Design Part 1 Course',
        'content': 26,
        'duration': '4h 24min',
        'icon': Icons.military_tech,
        'color': Colors.red,
        'completionDate': DateTime.now().subtract(const Duration(days: 5)), // Tambahkan tanggal selesai
      },
      {
        'title': 'Completed UI Design Part 1 Course',
        'content': 26,
        'duration': '4h 24min',
        'icon': Icons.emoji_events,
        'color': Colors.amber,
        'completionDate': DateTime.now().subtract(const Duration(hours: 10)),
      },
      {
        'title': 'Completed UI Design Part 1 Course',
        'content': 26,
        'duration': '4h 24min',
        'icon': Icons.star,
        'color': Colors.pink,
        'completionDate': DateTime.now().subtract(const Duration(days: 20)),
      },
      {
        'title': 'Completed UI Design Part 1 Course',
        'content': 26,
        'duration': '4h 24min',
        'icon': Icons.bookmark,
        'color': Colors.blue,
        'completionDate': DateTime.now().subtract(const Duration(minutes: 45)),
      },
    ];
  }

  // Fungsi untuk mengurutkan achievement
  void _sortAchievements() {
    setState(() {
      if (_selectedSortOption == 'New') {
        achievements.sort((a, b) => (b['completionDate'] as DateTime).compareTo(a['completionDate'] as DateTime));
      } else if (_selectedSortOption == 'Old') {
        achievements.sort((a, b) => (a['completionDate'] as DateTime).compareTo(b['completionDate'] as DateTime));
      } else { // Latest (default)
        achievements.sort((a, b) => (b['completionDate'] as DateTime).compareTo(a['completionDate'] as DateTime));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Achievment (${achievements.length})',
          style: const TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          // Ganti IconButton dan Icon dengan PopupMenuButton
          PopupMenuButton<String>(
            initialValue: _selectedSortOption,
            onSelected: (String result) {
              setState(() {
                _selectedSortOption = result;
                _sortAchievements(); // Panggil fungsi pengurutan
              });
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'Latest',
                child: Text(
                  'Latest',
                  style: TextStyle(
                    color: _selectedSortOption == 'Latest' ? AppColors.primaryBlue : Colors.black87,
                    fontWeight: _selectedSortOption == 'Latest' ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
              PopupMenuItem<String>(
                value: 'New',
                child: Text(
                  'New',
                  style: TextStyle(
                    color: _selectedSortOption == 'New' ? AppColors.primaryBlue : Colors.black87,
                    fontWeight: _selectedSortOption == 'New' ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
              PopupMenuItem<String>(
                value: 'Old',
                child: Text(
                  'Old',
                  style: TextStyle(
                    color: _selectedSortOption == 'Old' ? AppColors.primaryBlue : Colors.black87,
                    fontWeight: _selectedSortOption == 'Old' ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
            ],
            child: Row(
              children: [
                Text(
                  _selectedSortOption, // Tampilkan pilihan yang sedang aktif
                  style: const TextStyle(
                    color: AppColors.primaryBlue,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Icon(Icons.arrow_drop_down, color: AppColors.primaryBlue),
                const SizedBox(width: 8),
              ],
            ),
          ),
        ],
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(20),
        itemCount: achievements.length,
        itemBuilder: (context, index) {
          return _buildAchievementItem(achievements[index]);
        },
      ),
    );
  }

  Widget _buildAchievementItem(Map<String, dynamic> achievement) {
    IconData iconData = Icons.military_tech;
    if (achievement['icon'] == Icons.emoji_events) {
      iconData = Icons.emoji_events;
    } else if (achievement['icon'] == Icons.star) {
      iconData = Icons.star;
    } else if (achievement['icon'] == Icons.bookmark) {
      iconData = Icons.bookmark;
    }

    Color iconColor = Colors.red;
    if (achievement['color'] == Colors.amber) {
      iconColor = Colors.amber.shade700;
    } else if (achievement['color'] == Colors.pink) {
      iconColor = Colors.pink.shade400;
    } else if (achievement['color'] == Colors.blue) {
      iconColor = Colors.blue.shade600;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  achievement['title'],
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Icon(Icons.library_books_outlined,
                        size: 16, color: Colors.grey[600]),
                    const SizedBox(width: 4),
                    Text(
                      '${achievement['content']} Content',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[700],
                      ),
                    ),
                    const SizedBox(width: 16),
                    Icon(Icons.access_time, size: 16, color: Colors.grey[600]),
                    const SizedBox(width: 4),
                    Text(
                      achievement['duration'],
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey[700],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Icon(
            iconData,
            color: iconColor,
            size: 48,
          ),
        ],
      ),
    );
  }
}