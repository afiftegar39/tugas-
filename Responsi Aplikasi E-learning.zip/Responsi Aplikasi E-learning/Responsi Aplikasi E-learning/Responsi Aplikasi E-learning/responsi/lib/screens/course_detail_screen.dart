// screens/course_detail_screen.dart
import 'package:flutter/material.dart';
import '../constants/colors.dart';
import '../models/course_model.dart';
import '../models/user_model.dart';
import '../services/course_service.dart';
import '../services/auth_service.dart';
import './achievement_screen.dart';
import './discussion_screen.dart';
import './edit_course_screen.dart';

class CourseDetailScreen extends StatefulWidget {
  final int courseId;
  final String category;
  final String title;
  final String content;
  final double rating;
  final String imageUrl;
  final int reviewCount;
  final int joinedCount;

  const CourseDetailScreen({
    Key? key,
    required this.courseId,
    required this.category,
    required this.title,
    required this.content,
    required this.rating,
    required this.imageUrl,
    this.reviewCount = 128,
    this.joinedCount = 456,
  }) : super(key: key);

  @override
  State<CourseDetailScreen> createState() => _CourseDetailScreenState();
}

class _CourseDetailScreenState extends State<CourseDetailScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool isBookmarked = false;
  bool _isLoading = true;
  Course? _courseDetail;
  User? _currentUser;
  bool _canEdit = false;
  bool _isEnrolling = false;
  bool _isEnrolled = false;

  final ScrollController _scrollController = ScrollController();
  bool _showHeader = false;

  final List<Map<String, dynamic>> courses = [
    {
      'number': 1,
      'title': 'What is this course?',
      'duration': '24min',
      'isLocked': false,
    },
    {
      'number': 2,
      'title': 'How it Works?',
      'duration': '24min',
      'isLocked': false,
    },
    {
      'number': 3,
      'title': 'Why learn this?',
      'duration': '24min',
      'isLocked': false,
    },
    {
      'number': 4,
      'title': 'Practice Part 1',
      'duration': '24min',
      'isLocked': true,
    },
    {
      'number': 5,
      'title': 'Practice Part 2',
      'duration': '24min',
      'isLocked': true,
    },
  ];

  final List<String> profileImages = [
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80',
    'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&q=80',
    'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&q=80',
    'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&q=80',
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _scrollController.addListener(_onScroll);
    _loadCourseDetail();
    _loadUser();
  }

  Future<void> _loadUser() async {
    try {
      final user = await AuthService.getLocalProfile();
      if (mounted) {
        setState(() {
          _currentUser = user;
        });
      }
    } catch (e) {
      print('Load user error: $e');
    }
  }

  Future<void> _loadCourseDetail() async {
    setState(() => _isLoading = true);

    try {
      final course = await CourseService.getCourseDetail(widget.courseId);
      if (course != null && mounted) {
        setState(() {
          _courseDetail = course;
          _canEdit = _currentUser?.id == course.instructorId;
          _isLoading = false;
        });
      } else if (mounted) {
        setState(() => _isLoading = false);
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        _showError('Failed to load course details');
      }
    }
  }

  void _onScroll() {
    if (_scrollController.offset > 150 && !_showHeader) {
      setState(() => _showHeader = true);
    } else if (_scrollController.offset <= 150 && _showHeader) {
      setState(() => _showHeader = false);
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showSuccess(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _handleEnroll() async {
    if (_isEnrolling || _isEnrolled) return;

    setState(() => _isEnrolling = true);

    try {
      final result = await CourseService.enrollCourse(widget.courseId);
      
      if (result['success'] == true) {
        setState(() {
          _isEnrolled = true;
          _isEnrolling = false;
        });
        _showSuccess('Successfully enrolled in course!');
        _loadCourseDetail(); // Refresh data
      } else {
        setState(() => _isEnrolling = false);
        _showError(result['message'] ?? 'Enrollment failed');
      }
    } catch (e) {
      setState(() => _isEnrolling = false);
      _showError(e.toString().replaceAll('Exception: ', ''));
    }
  }

  Future<void> _handleEdit() async {
    if (_courseDetail == null) return;

    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditCourseScreen(course: _courseDetail!),
      ),
    );

    if (result == true) {
      _showSuccess('Course updated successfully');
      _loadCourseDetail();
    }
  }

  Future<void> _handleDelete() async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Course'),
        content: const Text('Are you sure you want to delete this course? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (shouldDelete == true) {
      try {
        final result = await CourseService.deleteCourse(widget.courseId);
        
        if (result['success'] == true) {
          _showSuccess('Course deleted successfully');
          Navigator.pop(context, true);
        } else {
          _showError(result['message'] ?? 'Delete failed');
        }
      } catch (e) {
        _showError(e.toString().replaceAll('Exception: ', ''));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: Stack(
        children: [
          _buildBackgroundImage(),
          _buildScrollableContent(),
          _buildAnimatedHeader(),
          _buildBackButton(),
        ],
      ),
      bottomNavigationBar: _buildBottomBar(),
    );
  }

  Widget _buildBackgroundImage() {
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      height: MediaQuery.of(context).size.height * 0.4,
      child: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage(widget.imageUrl),
            fit: BoxFit.cover,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withOpacity(0.6),
                Colors.black.withOpacity(0.3),
                Colors.transparent,
              ],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 40),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColors.primaryBlue,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      widget.category,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    widget.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      const Icon(Icons.play_circle_outline, color: Colors.white, size: 18),
                      const SizedBox(width: 6),
                      Text(
                        widget.content,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(width: 20),
                      const Icon(Icons.access_time, color: Colors.white, size: 18),
                      const SizedBox(width: 6),
                      Text(
                        _courseDetail?.duration ?? '4h 24min',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildScrollableContent() {
    return NotificationListener<ScrollNotification>(
      child: CustomScrollView(
        controller: _scrollController,
        slivers: [
          SliverToBoxAdapter(
            child: SizedBox(height: MediaQuery.of(context).size.height * 0.35),
          ),
          SliverToBoxAdapter(
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: Column(
                children: [
                  _buildProfileSection(),
                  _buildTabBar(),
                ],
              ),
            ),
          ),
          SliverFillRemaining(
            child: Container(
              color: Colors.white,
              child: TabBarView(
                controller: _tabController,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _buildCoursesTab(),
                  Container(color: Colors.white),
                  Container(color: Colors.white),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 24, 20, 16),
      child: Row(
        children: [
          SizedBox(
            width: 140,
            height: 45,
            child: Stack(
              children: List.generate(4, (i) {
                return Positioned(
                  left: i * 28.0,
                  child: Container(
                    width: 45,
                    height: 45,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 3),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: ClipOval(
                      child: Image.network(
                        profileImages[i],
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Container(
                            color: Colors.grey[300],
                            child: Icon(Icons.person, color: Colors.grey[600]),
                          );
                        },
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              '${_courseDetail?.joinedCount ?? widget.joinedCount} People Joined',
              style: const TextStyle(
                color: Colors.grey,
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                _courseDetail?.rating.toStringAsFixed(1) ?? widget.rating.toStringAsFixed(1),
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              Row(
                children: List.generate(5, (index) {
                  final rating = _courseDetail?.rating ?? widget.rating;
                  if (index < rating.floor()) {
                    return const Icon(Icons.star, color: AppColors.orange, size: 18);
                  } else if (index < rating) {
                    return const Icon(Icons.star_half, color: AppColors.orange, size: 18);
                  } else {
                    return Icon(Icons.star_border, color: Colors.grey[300], size: 18);
                  }
                }),
              ),
              const SizedBox(height: 2),
              Text(
                '(${_courseDetail?.reviewCount ?? widget.reviewCount} reviews)',
                style: const TextStyle(color: Colors.grey, fontSize: 12),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.grey[200]!, width: 1)),
      ),
      child: TabBar(
        controller: _tabController,
        labelColor: Colors.black87,
        unselectedLabelColor: Colors.grey,
        labelStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        unselectedLabelStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
        indicatorColor: AppColors.primaryBlue,
        indicatorWeight: 3,
        onTap: (index) {
          if (index == 1) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const DiscussionScreen()),
            ).then((_) {
              if (mounted) _tabController.animateTo(0);
            });
          } else if (index == 2) {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AchievementScreen()),
            ).then((_) {
              if (mounted) _tabController.animateTo(0);
            });
          }
        },
        tabs: const [
          Tab(text: 'Courses'),
          Tab(text: 'Reviews'),
          Tab(text: 'Achievement'),
        ],
      ),
    );
  }

  Widget _buildCoursesTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: courses.length,
      itemBuilder: (context, index) {
        final course = courses[index];
        return _buildCourseItem(
          course['number'],
          course['title'],
          course['duration'],
          course['isLocked'] ?? false,
        );
      },
    );
  }

  Widget _buildCourseItem(int number, String title, String duration, bool isLocked) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey[200]!),
      ),
      child: Row(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: isLocked ? Colors.grey[100] : const Color(0xFFEEF2FF),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                '#$number',
                style: TextStyle(
                  color: isLocked ? Colors.grey[400] : AppColors.primaryBlue,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: isLocked ? Colors.grey[400] : Colors.black87,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  duration,
                  style: TextStyle(fontSize: 13, color: Colors.grey[600]),
                ),
              ],
            ),
          ),
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: isLocked ? Colors.grey[300] : AppColors.primaryBlue,
              shape: BoxShape.circle,
            ),
            child: Icon(
              isLocked ? Icons.lock : Icons.play_arrow,
              color: Colors.white,
              size: 24,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedHeader() {
    return AnimatedPositioned(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      top: _showHeader ? 0 : -70,
      left: 0,
      right: 0,
      child: Container(
        height: 70,
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: const SafeArea(child: SizedBox.shrink()),
      ),
    );
  }

  Widget _buildBackButton() {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              child: IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: _showHeader ? Colors.black87 : Colors.white,
                  size: 28,
                ),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            if (_canEdit)
              PopupMenuButton<String>(
                icon: Icon(
                  Icons.more_vert,
                  color: _showHeader ? Colors.black87 : Colors.white,
                  size: 28,
                ),
                onSelected: (value) {
                  if (value == 'edit') {
                    _handleEdit();
                  } else if (value == 'delete') {
                    _handleDelete();
                  }
                },
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'edit',
                    child: Row(
                      children: [
                        Icon(Icons.edit, size: 20),
                        SizedBox(width: 12),
                        Text('Edit Course'),
                      ],
                    ),
                  ),
                  const PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete, size: 20, color: Colors.red),
                        SizedBox(width: 12),
                        Text('Delete Course', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomBar() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        child: Row(
          children: [
            GestureDetector(
              onTap: () {
                setState(() => isBookmarked = !isBookmarked);
              },
              child: Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  color: const Color(0xFFFF1744),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  isBookmarked ? Icons.bookmark : Icons.bookmark_border,
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Container(
                height: 56,
                decoration: BoxDecoration(
                  color: _canEdit ? Colors.grey[400] : AppColors.primaryBlue,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: _canEdit ? null : (_isEnrolling ? null : _handleEnroll),
                    borderRadius: BorderRadius.circular(12),
                    child: Center(
                      child: _isEnrolling
                          ? const SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                color: Colors.white,
                                strokeWidth: 2,
                              ),
                            )
                          : Text(
                              _canEdit
                                  ? 'YOUR COURSE'
                                  : _isEnrolled
                                      ? 'ENROLLED'
                                      : 'ENROLL (\$${_courseDetail?.price.toStringAsFixed(1) ?? '5.6'})',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                              ),
                            ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}