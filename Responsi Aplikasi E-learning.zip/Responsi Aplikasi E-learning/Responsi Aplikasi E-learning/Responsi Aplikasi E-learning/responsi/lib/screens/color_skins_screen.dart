// lib/screens/color_skins_screen.dart
import 'package:flutter/material.dart';
import '../constants/colors.dart';
import 'home_screen.dart';

class ColorSkinsScreen extends StatefulWidget {
  const ColorSkinsScreen({Key? key}) : super(key: key);

  @override
  State<ColorSkinsScreen> createState() => _ColorSkinsScreenState();
}

class _ColorSkinsScreenState extends State<ColorSkinsScreen> {
  // State untuk menyimpan pilihan user
  String selectedLayoutTheme = 'light'; // 'light' atau 'dark'
  String? selectedColorTheme; // nama color theme yang dipilih
  Color? customColor; // untuk custom color

  // Daftar warna
  final Map<String, Color> colorThemes = const {
    'Red': Colors.red,
    'Green': Colors.green,
    'Blue': Colors.blue,
    'Pink': Colors.pink,
    'Yellow': Colors.yellow,
    'Orange': Colors.orange,
    'Purple': Colors.purple,
    'Deeppurple': Colors.deepPurple,
    'Lightblue': Colors.lightBlue,
    'Teal': Colors.teal,
    'Lime': Colors.lime,
    'Deeporange': Colors.deepOrange,
  };

  // Fungsi untuk mengubah Color ke string HEX
  String colorToHex(Color color) {
    return '#${color.value.toRadixString(16).padLeft(8, '0').substring(2).toLowerCase()}';
  }

  // Fungsi untuk mendapatkan warna yang aktif
  Color getActiveColor() {
    if (customColor != null) {
      return customColor!;
    } else if (selectedColorTheme != null) {
      return colorThemes[selectedColorTheme]!;
    } else {
      return AppColors.primaryBlue; // default
    }
  }

  // Fungsi untuk mendapatkan background color berdasarkan theme
  Color getBackgroundColor() {
    return selectedLayoutTheme == 'dark' ? Colors.grey[900]! : Colors.grey[100]!;
  }

  // Fungsi untuk mendapatkan card color berdasarkan theme
  Color getCardColor() {
    return selectedLayoutTheme == 'dark' ? Colors.grey[850]! : Colors.white;
  }

  // Fungsi untuk mendapatkan text color berdasarkan theme
  Color getTextColor() {
    return selectedLayoutTheme == 'dark' ? Colors.white : Colors.black87;
  }

  // Fungsi untuk mendapatkan secondary text color
  Color getSecondaryTextColor() {
    return selectedLayoutTheme == 'dark' ? Colors.grey[400]! : Colors.grey[600]!;
  }

  @override
  Widget build(BuildContext context) {
    final activeColor = getActiveColor();

    return Scaffold(
      backgroundColor: getBackgroundColor(),
      appBar: AppBar(
        backgroundColor: getCardColor(),
        elevation: 1,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: getTextColor()),
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            } else {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const HomeScreen()),
              );
            }
          },
        ),
        title: Text(
          'Color Themes',
          style: TextStyle(color: getTextColor(), fontSize: 18),
        ),
        actions: [
          TextButton(
            onPressed: () {
              _showSelectionSummary();
            },
            child: Text(
              'Apply',
              style: TextStyle(
                color: activeColor,
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Color Themes',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: getTextColor(),
              ),
            ),
            const SizedBox(height: 24),
            _buildLayoutThemes(),
            const SizedBox(height: 24),
            _buildDefaultColorThemes(context),
            const SizedBox(height: 24),
            _buildCustomColorTheme(),
            const SizedBox(height: 24),
            _buildSelectionPreview(),
          ],
        ),
      ),
      bottomNavigationBar: _buildCustomBottomNav(),
    );
  }

  Widget _buildLayoutThemes() {
    final activeColor = getActiveColor();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Layout Themes',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: getTextColor(),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Framework7 comes with 2 main layout themes: Light (default) and Dark:',
          style: TextStyle(color: getSecondaryTextColor()),
        ),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: getCardColor(),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: selectedLayoutTheme == 'dark' ? Colors.grey[700]! : Colors.grey[300]!),
          ),
          child: Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedLayoutTheme = 'light';
                      // Reset selection saat ganti ke light mode
                    });
                  },
                  child: Container(
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: selectedLayoutTheme == 'light'
                            ? activeColor
                            : Colors.grey[300]!,
                        width: selectedLayoutTheme == 'light' ? 3 : 1,
                      ),
                    ),
                    child: selectedLayoutTheme == 'light'
                        ? Icon(
                      Icons.check_circle,
                      color: activeColor,
                    )
                        : const Icon(
                      Icons.wb_sunny_outlined,
                      color: Colors.grey,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedLayoutTheme = 'dark';
                      // Reset ke default saat ganti ke dark mode
                      selectedColorTheme = null;
                      customColor = null;
                    });
                  },
                  child: Container(
                    height: 60,
                    decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: selectedLayoutTheme == 'dark'
                            ? activeColor
                            : Colors.grey[700]!,
                        width: selectedLayoutTheme == 'dark' ? 3 : 1,
                      ),
                    ),
                    child: selectedLayoutTheme == 'dark'
                        ? Icon(
                      Icons.check_circle,
                      color: activeColor,
                    )
                        : const Icon(
                      Icons.nightlight_outlined,
                      color: Colors.white70,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDefaultColorThemes(BuildContext context) {
    // Cek apakah dark mode aktif
    final bool isDarkMode = selectedLayoutTheme == 'dark';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Default Color Themes',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: getTextColor(),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Framework7 comes with 12 color themes set.',
          style: TextStyle(color: getSecondaryTextColor()),
        ),
        const SizedBox(height: 16),

        // Tambahkan overlay atau opacity saat dark mode
        Opacity(
          opacity: isDarkMode ? 0.4 : 1.0,
          child: IgnorePointer(
            ignoring: isDarkMode, // Disable interaction saat dark mode
            child: Wrap(
              spacing: 12.0,
              runSpacing: 12.0,
              children: colorThemes.entries.map((entry) {
                return _buildColorSwatch(context, entry.key, entry.value, isDarkMode);
              }).toList(),
            ),
          ),
        ),

        // Tambahkan pesan jika dark mode aktif
        if (isDarkMode)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Row(
              children: [
                Icon(Icons.info_outline, size: 16, color: getSecondaryTextColor()),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Default color themes are disabled in dark mode',
                    style: TextStyle(
                      fontSize: 12,
                      color: getSecondaryTextColor(),
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildColorSwatch(BuildContext context, String name, Color color, bool isDisabled) {
    final isSelected = selectedColorTheme == name && customColor == null && !isDisabled;

    return GestureDetector(
      onTap: isDisabled ? null : () {
        setState(() {
          selectedColorTheme = name;
          customColor = null; // reset custom color
        });
      },
      child: Container(
        width: (MediaQuery.of(context).size.width / 2) - 22,
        height: 50,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(8),
          border: isSelected
              ? Border.all(color: Colors.white, width: 3)
              : null,
          boxShadow: isSelected
              ? [
            BoxShadow(
              color: color.withOpacity(0.5),
              blurRadius: 8,
              spreadRadius: 2,
            )
          ]
              : null,
        ),
        child: Stack(
          children: [
            Center(
              child: Text(
                name,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(
                      blurRadius: 2,
                      color: Colors.black38,
                    )
                  ],
                ),
              ),
            ),
            if (isSelected)
              const Positioned(
                top: 4,
                right: 4,
                child: Icon(
                  Icons.check_circle,
                  color: Colors.white,
                  size: 24,
                  shadows: [
                    Shadow(
                      blurRadius: 4,
                      color: Colors.black38,
                    )
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildCustomColorTheme() {
    final Color imageCustomColor = const Color(0xFF673ab7);
    final bool isSelected = customColor == imageCustomColor;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Custom Color Theme',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: getTextColor(),
          ),
        ),
        const SizedBox(height: 16),

        GestureDetector(
          onTap: () {
            setState(() {
              customColor = imageCustomColor;
              selectedColorTheme = null;
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: getCardColor(),
              borderRadius: BorderRadius.circular(8),
              border: isSelected
                  ? Border.all(color: getActiveColor(), width: 2)
                  : Border.all(color: selectedLayoutTheme == 'dark' ? Colors.grey[700]! : Colors.grey[300]!),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: imageCustomColor,
                    borderRadius: BorderRadius.circular(6),
                  ),
                ),
                const SizedBox(width: 16),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'HEX Color',
                      style: TextStyle(
                        color: getSecondaryTextColor(),
                        fontSize: 12,
                      ),
                    ),
                    Text(
                      colorToHex(imageCustomColor),
                      style: TextStyle(
                        color: getTextColor(),
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const Spacer(),
                if (isSelected)
                  Icon(
                    Icons.check_circle,
                    color: getActiveColor(),
                    size: 24,
                  )
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSelectionPreview() {
    final activeColor = getActiveColor();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: getCardColor(),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
            color: selectedLayoutTheme == 'dark' ? Colors.grey[700]! : Colors.grey[300]!
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Current Selection',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: getTextColor(),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Icon(Icons.palette, color: activeColor, size: 20),
              const SizedBox(width: 8),
              Text(
                'Layout: ${selectedLayoutTheme == 'light' ? 'Light' : 'Dark'}',
                style: TextStyle(fontSize: 14, color: getTextColor()),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(Icons.color_lens, color: activeColor, size: 20),
              const SizedBox(width: 8),
              Text(
                'Color: ${customColor != null ? colorToHex(customColor!) : selectedColorTheme ?? 'Default Blue'}',
                style: TextStyle(fontSize: 14, color: getTextColor()),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: activeColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: activeColor, width: 2),
            ),
            child: Row(
              children: [
                Icon(Icons.star, color: activeColor, size: 24),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'This is how your theme looks!',
                    style: TextStyle(
                      color: activeColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showSelectionSummary() {
    final activeColor = getActiveColor();

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: getCardColor(),
          title: Text(
            'Theme Applied Successfully!',
            style: TextStyle(color: getTextColor()),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.check_circle, color: activeColor, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'Layout: ${selectedLayoutTheme == 'light' ? 'Light' : 'Dark'}',
                    style: TextStyle(color: getTextColor()),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.check_circle, color: activeColor, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Color: ${customColor != null ? colorToHex(customColor!) : selectedColorTheme ?? 'Default Blue'}',
                      style: TextStyle(color: getTextColor()),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: activeColor,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                  child: Text(
                    'Preview',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                'OK',
                style: TextStyle(
                  color: activeColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildCustomBottomNav() {
    final activeColor = getActiveColor();

    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      backgroundColor: getCardColor(),
      selectedItemColor: activeColor,
      unselectedItemColor: selectedLayoutTheme == 'dark' ? Colors.grey[600] : Colors.grey,
      showSelectedLabels: true,
      showUnselectedLabels: true,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.mail_outline),
          label: 'Inbox',
        ),
        BottomNavigationBarItem(
          icon: Badge(
            label: Text('5'),
            child: Icon(Icons.calendar_today_outlined),
          ),
          label: 'Calendar',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.upload_outlined),
          label: 'Upload',
        ),
      ],
    );
  }
}