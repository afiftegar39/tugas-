// lib/screens/elements_screen.dart
import 'package:flutter/material.dart'; // <-- INI PERBAIKANNYA
import '../constants/colors.dart';
import 'about_framework_screen.dart';

class ElementsScreen extends StatelessWidget {
  const ElementsScreen({Key? key}) : super(key: key);

  // Daftar semua elemen
  final List<String> elements = const [
    'About Framework7', 'Accordion', 'Action Sheet', 'Appbar', 'Autocomplete',
    'Badge', 'Buttons', 'Calendar / Date Picker', 'Cards', 'Cards Expandable',
    'Checkbox', 'Chips / Tags', 'Color Picker', 'Contacts List', 'Content Block',
    'Data Table', 'Dialog', 'Elevation', 'FAB', 'FAB Morph', 'Form Storage',
    'Gauge', 'Grid / Layout Grid', 'Icons', 'Infinite Scroll', 'Inputs',
    'Lazy Load', 'List View', 'List Index', 'Login Screen', 'Menu', 'Messages',
    'Navbar', 'Notifications', 'Panel / Side Panels', 'Photo Browser', 'Picker',
    'Popover', 'Popup', 'Preloader', 'Progress Bar', 'Pull To Refresh', 'Radio',
    'Range Slider', 'Searchbar', 'Searchbar Expandable', 'Sheet Modal',
    'Skeleton (Ghost) Layouts', 'Smart Select', 'Sortable list', 'Stepper',
    'Subnavbar', 'Swipeout (Swipe To Delete)', 'Swiper Slider', 'Tabs',
    'Text Editor', 'Timeline', 'Toast', 'Toggle', 'Toolbar & Tabbar', 'Tooltip',
    'Treeview', 'Virtual list', 'vi - Mobile Video SSP'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Framework7',
          style: TextStyle(color: Colors.black87, fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: Colors.black87),
            onPressed: () {},
          ),
        ],
      ),
      body: ListView.builder(
        itemCount: elements.length,
        itemBuilder: (context, index) {
          // Pisahkan "Components" title
          if (index == 1) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildElementTile(context, elements[index]),
                const Padding(
                  padding: EdgeInsets.only(left: 16.0, top: 20, bottom: 10),
                  child: Text(
                    'Components',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black54,
                    ),
                  ),
                ),
              ],
            );
          }
          if (index == 0) {
            return _buildElementTile(context, elements[index], isFirst: true);
          }
          return _buildElementTile(context, elements[index]);
        },
      ),
    );
  }

  // Widget helper untuk membuat list tile
  Widget _buildElementTile(BuildContext context, String title,
      {bool isFirst = false}) {
    return Container(
      margin: EdgeInsets.only(top: isFirst ? 8.0 : 0.0, left: 8.0, right: 8.0),
      decoration: BoxDecoration(
        color: isFirst ? Colors.grey[100] : Colors.transparent,
        borderRadius: isFirst ? BorderRadius.circular(10) : BorderRadius.zero,
      ),
      child: ListTile(
        leading: Icon(
          Icons.school, // Ikon topi toga
          color: AppColors.primaryBlue,
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 16,
            color: Colors.black87,
          ),
        ),
        trailing: const Icon(
          Icons.chevron_right,
          color: Colors.grey,
        ),
        // Tambahkan logika navigasi
        onTap: () {
          if (title == 'About Framework7') {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const AboutFrameworkScreen()),
            );
          } else {
            // Logika untuk item lainnya
          }
        },
      ),
    );
  }
}