// screens/discussion_screen.dart
import 'package:flutter/material.dart';
import '../constants/colors.dart';
import './write_review_screen.dart'; // <-- 1. IMPORT FILE BARU

class DiscussionScreen extends StatefulWidget {
  const DiscussionScreen({Key? key}) : super(key: key);

  @override
  State<DiscussionScreen> createState() => _DiscussionScreenState();
}

class _DiscussionScreenState extends State<DiscussionScreen> {
  // --- 2. HAPUS _reviewController ---
  // final TextEditingController _reviewController = TextEditingController();
  String _selectedSortOption = 'Latest';

  final List<String> profileImages = [
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&q=80',
    'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=100&q=80',
    'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&q=80',
    'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&q=80',
  ];

  late List<Map<String, dynamic>> discussions;

  @override
  void initState() {
    super.initState();
    discussions = _generateInitialDiscussions();
    _sortDiscussions();
  }

  List<Map<String, dynamic>> _generateInitialDiscussions() {
    return [
      // ... (data diskusi Anda tidak berubah)
      {
        'name': 'Kevin Sirait',
        'imageUrl': profileImages[0],
        'text': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod',
        'likes': 45,
        'replies': 4,
        'timestamp': DateTime.now().subtract(const Duration(hours: 2)),
      },
      {
        'name': 'Thomas Jono',
        'imageUrl': profileImages[1],
        'text': 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod',
        'likes': 45,
        'replies': 4,
        'timestamp': DateTime.now().subtract(const Duration(days: 1)),
      },
      {
        'name': 'Cinthya Moss',
        'imageUrl': profileImages[2],
        'text': 'Lorem ipsum dolor sit amet, consectetur',
        'timestamp': DateTime.now().subtract(const Duration(minutes: 30)),
      },
      {
        'name': 'Romeo Silalahi',
        'imageUrl': profileImages[3],
        'text': 'Lorem ipsum dolor sit amet, consectetur',
        'timestamp': DateTime.now().subtract(const Duration(hours: 5)),
      },
      {
        'name': 'Paula Jean',
        'imageUrl': profileImages[0],
        'text': 'Lorem ipsum dolor sit amet, consectetur',
        'timestamp': DateTime.now().subtract(const Duration(days: 3)),
      },
      {
        'name': 'Roberto Karlos',
        'imageUrl': profileImages[1],
        'text': 'Lorem ipsum dolor sit amet, consectetur',
        'timestamp': DateTime.now().subtract(const Duration(hours: 1)),
      },
    ];
  }

  void _sortDiscussions() {
    setState(() {
      if (_selectedSortOption == 'New') {
        discussions.sort((a, b) => (b['timestamp'] as DateTime).compareTo(a['timestamp'] as DateTime));
      } else if (_selectedSortOption == 'Old') {
        discussions.sort((a, b) => (a['timestamp'] as DateTime).compareTo(b['timestamp'] as DateTime));
      } else {
        discussions.sort((a, b) => (b['timestamp'] as DateTime).compareTo(a['timestamp'] as DateTime));
      }
    });
  }

  @override
  void dispose() {
    // --- 2. HAPUS _reviewController.dispose() ---
    super.dispose();
  }

  // --- 3. HAPUS _showAddReviewModal() ---
  /*
  void _showAddReviewModal() {
    ...
  }
  */

  // --- 4. BUAT FUNGSI NAVIGASI BARU ---
  Future<void> _navigateToAddReview() async {
    // Navigasi ke layar baru dan tunggu hasilnya (teks review)
    final String? newReviewText = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const WriteReviewScreen()),
    );

    // Jika pengguna mengirim review (bukan hanya menekan 'kembali')
    if (newReviewText != null && newReviewText.isNotEmpty) {
      _submitReview(newReviewText); // Panggil _submitReview dengan teks baru
    }
  }

  // --- 5. MODIFIKASI _submitReview() ---
  void _submitReview(String reviewText) { // Terima argumen String
    setState(() {
      discussions.insert(0, {
        'name': 'You', // Nama pengguna
        'imageUrl': profileImages[3], // Foto profil Anda
        'text': reviewText, // Gunakan teks dari argumen
        'timestamp': DateTime.now(), // Timestamp baru
      });
      // Hapus controller.clear() dan Navigator.pop()
      _sortDiscussions(); // Urutkan lagi setelah menambah review baru
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black87),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Discussions',
          style: TextStyle(
            color: Colors.black87,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        actions: [
          PopupMenuButton<String>(
            initialValue: _selectedSortOption,
            onSelected: (String result) {
              setState(() {
                _selectedSortOption = result;
                _sortDiscussions();
              });
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'Latest',
                child: Text(
                  'Latest',
                  style: TextStyle(
                    color: _selectedSortOption == 'Latest' ? AppColors.primaryBlue : Colors.black87,
                    fontWeight: _selectedSortOption == 'Latest' ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
              PopupMenuItem<String>(
                value: 'New',
                child: Text(
                  'New',
                  style: TextStyle(
                    color: _selectedSortOption == 'New' ? AppColors.primaryBlue : Colors.black87,
                    fontWeight: _selectedSortOption == 'New' ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
              PopupMenuItem<String>(
                value: 'Old',
                child: Text(
                  'Old',
                  style: TextStyle(
                    color: _selectedSortOption == 'Old' ? AppColors.primaryBlue : Colors.black87,
                    fontWeight: _selectedSortOption == 'Old' ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
            ],
            child: Row(
              children: [
                Text(
                  _selectedSortOption,
                  style: const TextStyle(
                    color: AppColors.primaryBlue,
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const Icon(Icons.arrow_drop_down, color: AppColors.primaryBlue),
                const SizedBox(width: 8),
              ],
            ),
          ),
        ],
        backgroundColor: Colors.white,
        elevation: 1,
      ),
      body: Stack(
        children: [
          ListView.builder(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 100),
            itemCount: discussions.length,
            itemBuilder: (context, index) {
              return _buildDiscussionItem(discussions[index]);
            },
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                    offset: const Offset(0, -5),
                  )
                ],
              ),
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                // --- 6. UBAH onPressed ---
                onPressed: _navigateToAddReview, // Ganti ke fungsi navigasi baru
                child: const Text(
                  'ADD REVIEW',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDiscussionItem(Map<String, dynamic> discussion) {
    bool hasActions = discussion['likes'] != null;

    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CircleAvatar(
                radius: 24,
                backgroundImage: NetworkImage(discussion['imageUrl']),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      discussion['name'],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      discussion['text'],
                      style: TextStyle(
                        color: Colors.grey[700],
                        fontSize: 14,
                        height: 1.4,
                      ),
                    ),
                    if (hasActions) const SizedBox(height: 12),
                    if (hasActions)
                      Row(
                        children: [
                          Icon(Icons.thumb_up_alt_outlined,
                              size: 16, color: Colors.green),
                          const SizedBox(width: 4),
                          Text(
                            '${discussion['likes']} Like',
                            style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 13,
                                fontWeight: FontWeight.w500),
                          ),
                          const SizedBox(width: 20),
                          Icon(Icons.reply_outlined,
                              size: 16, color: Colors.blue),
                          const SizedBox(width: 4),
                          Text(
                            '${discussion['replies']} Reply',
                            style: TextStyle(
                                color: Colors.grey[600],
                                fontSize: 13,
                                fontWeight: FontWeight.w500),
                          ),
                        ],
                      ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Divider(height: 1, color: Colors.grey[200]),
        ],
      ),
    );
  }
}