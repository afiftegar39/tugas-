class Course {
  final int id;
  final int instructorId;
  final String category;
  final String title;
  final String description;
  final int contentCount;
  final String duration;
  final double rating;
  final int reviewCount;
  final int joinedCount;
  final double price;
  final String imageUrl;
  final String status;
  final String? instructorName;

  Course({
    required this.id,
    required this.instructorId,
    required this.category,
    required this.title,
    required this.description,
    required this.contentCount,
    required this.duration,
    required this.rating,
    required this.reviewCount,
    required this.joinedCount,
    required this.price,
    required this.imageUrl,
    required this.status,
    this.instructorName,
  });

  factory Course.fromJson(Map<String, dynamic> json) {
    return Course(
      id: json['id'],
      instructorId: json['instructor_id'],
      category: json['category'],
      title: json['title'],
      description: json['description'],
      contentCount: json['content_count'],
      duration: json['duration'],
      rating: double.parse(json['rating'].toString()),
      reviewCount: json['review_count'],
      joinedCount: json['joined_count'],
      price: double.parse(json['price'].toString()),
      imageUrl: json['image_url'],
      status: json['status'],
      instructorName: json['instructor']?['name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'instructor_id': instructorId,
      'category': category,
      'title': title,
      'description': description,
      'content_count': contentCount,
      'duration': duration,
      'rating': rating,
      'review_count': reviewCount,
      'joined_count': joinedCount,
      'price': price,
      'image_url': imageUrl,
      'status': status,
    };
  }
}